# Airflow DAG Manager Plugin

Web-based file manager for Apache Airflow DAG files.

## Features

- 📂 Browse DAG folders with tree navigation
- 📝 Create, edit, rename, and delete files
- 📁 Create and delete folders
- 🔐 Role-based access control
- 📊 Audit logging to database
- 🔒 Security: path traversal protection, CSRF protection

## Installation

```bash
pip install airflow-dag-manager-0.1.0-py3-none-any.whl
```

## Configuration

Add to your `airflow.cfg`:

```ini
[dag_manager]
# Audit logging
logs_to_database = true
logs_db_schema = dpl

# Mount points (must start with "mount")
mount_dags = /opt/airflow/dags
mount_plugins = /opt/airflow/plugins
```

## Usage

After installation, the plugin will appear in Airflow UI under **Admin > DAG manage**.

## License

MIT License
